const textArea = document.getElementById("text_to_summarize");
const submitButton = document.getElementById("submit-button");
const summarizedTextArea = document.getElementById("summary");

submitButton.disabled = true;

textArea.addEventListener("input", verifyTextLength);
submitButton.addEventListener("click", submitData);

function verifyTextLength(e) {
 // The e.target property gives us the HTML element that triggered the event, which in this case is the textarea. We save this to a variable called 'textarea'
  const textarea = e.target;

  // Verify the TextArea value.
  if (textarea.value.length > 200 && textarea.value.length < 100000) {
    // Enable the button when text area has value.
    submitButton.disabled = false;
  } else {
    // Disable the button when text area is empty.
    submitButton.disabled = true;
  }
}

function submitData(e) {

 // This is used to add animation to the submit button
  submitButton.classList.add("submit-button--loading");

  const text_to_summarize = textArea.value;

  var myHeaders = new Headers();
  myHeaders.append("Content-Type", "application/json");

  var raw = JSON.stringify({
    "text_to_summarize": text_to_summarize
  });

  var requestOptions = {
    method: 'POST',
    headers: myHeaders,
    body: raw,
    redirect: 'follow'
  };

  // Send the text to the server using fetch API

   
  fetch('/summarize', requestOptions)
    .then(response => response.text()) // Response will be summarized text
    .then(summary => {
      

      // Update the output text area with new summary
      summarizedTextArea.value = summary;

      // Stop the spinning loading animation
      submitButton.classList.remove("submit-button--loading");
    })
    .catch(error => {
      console.log(error.message);
    });
}
const clearButton = document.getElementById("clear-button");

clearButton.addEventListener("click", clearSummary);

function clearSummary() {
  summarizedTextArea.value = ""; // Clear the summarized text area
}

const clearInputButton = document.getElementById("clear-input-button");

clearInputButton.addEventListener("click", clearInput);

function clearInput() {
  textArea.value = ""; // Clear the input text area
  submitButton.disabled = true; // Disable the submit button after clearing input
}


const textToSpeechButton = document.getElementById("text-to-speech-button");

textToSpeechButton.addEventListener("click", convertToSpeech);

function convertToSpeech() {
  const summaryText = summarizedTextArea.value;

  // Check if the browser supports speech synthesis
  if ('speechSynthesis' in window) {
    // Create a new SpeechSynthesisUtterance instance with the summary text
    const utterance = new SpeechSynthesisUtterance(summaryText);

    // Speak the text
    window.speechSynthesis.speak(utterance);
  } else {
    // Browser doesn't support speech synthesis
    alert("Sorry, your browser doesn't support speech synthesis.");
  }
}
const stopButton = document.getElementById("stop-button");
let isSpeaking = false; // Variable to track if speech is currently speaking

stopButton.addEventListener("click", toggleSpeech);

function toggleSpeech() {
    // Check if speech synthesis is supported
    if ('speechSynthesis' in window) {
        if (isSpeaking) {
            // If speech is currently speaking, pause it
            window.speechSynthesis.pause();
        } else {
            // If speech is not active or paused, resume it
            window.speechSynthesis.resume();
        }
        isSpeaking = !isSpeaking; // Toggle the speaking state
    } else {
        // Browser doesn't support speech synthesis
        alert("Sorry, your browser doesn't support speech synthesis.");
    }
}




